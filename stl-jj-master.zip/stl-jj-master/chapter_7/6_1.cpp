#include <iostream>
#include <functional>
using namespce std;

int main()
{
	greateer<int> ig;
	cout << boolapaha << ig(4, 6);  // (A) false
	cout << greater<int>()(6, 4);   // (B) true  调用的意思

}
