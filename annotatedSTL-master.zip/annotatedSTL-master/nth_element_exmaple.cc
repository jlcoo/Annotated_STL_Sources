#include <iostream>
using namespace std;
main(){
  std::nth_element();
  copy_backward(_BI1 __first, _BI1 __last, _BI2 __result);
  String::find_last_not_of(char __c);
  typename iterator_traits<Bid>::difftime(time_t __time1, time_t __time0)
}

